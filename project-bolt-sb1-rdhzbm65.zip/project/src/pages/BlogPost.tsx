import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Calendar, Clock, ArrowLeft, TrendingUp, DollarSign, Target } from 'lucide-react';

const BlogPost = () => {
  const { id } = useParams();

  // In a real app, you'd fetch this data based on the ID
  const post = {
    id: 'f1-sponsorship-valuations-2025',
    title: 'The Evolution of Formula 1 Sponsorship Valuations: A 2025 Market Analysis',
    date: '2025-01-15',
    readTime: '8 min read',
    image: 'https://images.pexels.com/photos/12832673/pexels-photo-12832673.jpeg',
    author: 'Danielle Crespo'
  };

  if (id !== 'f1-sponsorship-valuations-2025') {
    return (
      <main className="pt-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Post Not Found</h1>
          <Link to="/blog" className="text-blue-600 hover:text-blue-700">
            ← Back to Blog
          </Link>
        </div>
      </main>
    );
  }

  return (
    <main className="pt-16">
      {/* Back to Blog */}
      <div className="bg-gray-50 py-4">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link
            to="/insights"
            className="inline-flex items-center text-blue-600 hover:text-blue-700 font-medium"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Insights
          </Link>
        </div>
      </div>

      {/* Article Header */}
      <div className="bg-white py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center text-sm text-gray-500 mb-6">
            <Calendar className="h-4 w-4 mr-2" />
            <span>{new Date(post.date).toLocaleDateString('en-US', { 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}</span>
            <Clock className="h-4 w-4 ml-4 mr-2" />
            <span>{post.readTime}</span>
            <span className="ml-4">By {post.author}</span>
          </div>
          
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-8 leading-tight">
            {post.title}
          </h1>
          
          <div 
            className="aspect-video bg-cover bg-center rounded-lg shadow-lg mb-12"
            style={{ backgroundImage: `url(${post.image})` }}
          ></div>
        </div>
      </div>

      {/* Article Content */}
      <div className="bg-white pb-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="prose prose-lg max-w-none">
            <p className="text-xl text-gray-700 leading-relaxed mb-8">
              Formula 1's meteoric rise in global popularity, particularly following the success of Netflix's "Drive to Survive" 
              and the sport's expansion into new markets, has fundamentally transformed the sponsorship landscape. As we enter 2025, 
              sponsorship valuations have reached levels that would have been unimaginable just a decade ago.
            </p>

            <div className="grid md:grid-cols-3 gap-6 my-12 not-prose">
              <div className="bg-blue-50 p-6 rounded-lg text-center">
                <TrendingUp className="h-8 w-8 text-blue-600 mx-auto mb-3" />
                <div className="text-2xl font-bold text-gray-900">247%</div>
                <div className="text-sm text-gray-600">Average valuation increase since 2020</div>
              </div>
              <div className="bg-green-50 p-6 rounded-lg text-center">
                <DollarSign className="h-8 w-8 text-green-600 mx-auto mb-3" />
                <div className="text-2xl font-bold text-gray-900">$89M</div>
                <div className="text-sm text-gray-600">Average title sponsorship value</div>
              </div>
              <div className="bg-purple-50 p-6 rounded-lg text-center">
                <Target className="h-8 w-8 text-purple-600 mx-auto mb-3" />
                <div className="text-2xl font-bold text-gray-900">1.9B</div>
                <div className="text-sm text-gray-600">Global TV audience reach</div>
              </div>
            </div>

            <h2 className="text-3xl font-bold text-gray-900 mt-12 mb-6">The Digital Revolution Factor</h2>
            
            <p>
              The digital transformation of Formula 1 has been perhaps the most significant driver of increased sponsorship valuations. 
              Liberty Media's investment in digital content, social media engagement, and streaming platforms has created new touchpoints 
              for sponsor visibility that extend far beyond traditional race broadcast.
            </p>

            <p>
              Social media engagement alone has increased by over 400% since 2019, with F1's official accounts generating billions 
              of impressions annually. This digital ecosystem provides sponsors with measurable, granular data on audience engagement 
              that traditional motorsports sponsorship could never offer.
            </p>

            <h2 className="text-3xl font-bold text-gray-900 mt-12 mb-6">Market Expansion and New Demographics</h2>
            
            <p>
              Formula 1's strategic expansion into new markets, particularly in North America and Asia, has created unprecedented 
              opportunities for sponsors. The Las Vegas Grand Prix's debut season generated over $1.3 billion in economic impact, 
              while Miami continues to attract premium sponsors seeking access to affluent American audiences.
            </p>

            <blockquote className="border-l-4 border-blue-600 pl-6 my-8 italic text-lg text-gray-700">
              "The demographic shift we're seeing in F1 is remarkable. The average age of viewers has dropped significantly, 
              and we're seeing unprecedented female engagement. For sponsors, this represents access to demographics that 
              were previously difficult to reach through traditional motorsports." 
              <span className="block mt-2 text-base not-italic">— Industry Analysis, 2024</span>
            </blockquote>

            <h2 className="text-3xl font-bold text-gray-900 mt-12 mb-6">Valuation Methodology Evolution</h2>
            
            <p>
              The methodologies for calculating sponsorship valuations have evolved significantly. Traditional metrics focused 
              primarily on television broadcast time and static logo visibility. Modern valuations now incorporate:
            </p>

            <ul className="space-y-2 my-6">
              <li><strong>Digital engagement metrics</strong> - Social media interactions, content shares, and online mentions</li>
              <li><strong>Audience quality scores</strong> - Demographic analysis and purchasing power assessments</li>
              <li><strong>Activation multipliers</strong> - Potential for experiential marketing and fan engagement</li>
              <li><strong>Data access premiums</strong> - Rights to audience data and insights</li>
              <li><strong>ESG alignment values</strong> - Sustainability and social responsibility messaging opportunities</li>
            </ul>

            <h2 className="text-3xl font-bold text-gray-900 mt-12 mb-6">Looking Ahead: 2025 Projections</h2>
            
            <p>
              Based on current market trends and upcoming calendar expansions, we project continued growth in F1 sponsorship 
              valuations throughout 2025. Key factors supporting this outlook include:
            </p>

            <p>
              The addition of new race venues, particularly the potential for additional North American races, will further 
              increase global reach. Technology partnerships, especially in areas like sustainable fuels and electric vehicle 
              technology, command premium valuations as automotive manufacturers seek to showcase innovation.
            </p>

            <h2 className="text-3xl font-bold text-gray-900 mt-12 mb-6">Strategic Recommendations for Sponsors</h2>
            
            <p>
              For organizations considering F1 sponsorship investments in 2025, several strategic considerations emerge:
            </p>

            <p>
              <strong>Focus on activation potential:</strong> Pure logo visibility deals are becoming less valuable compared to 
              partnerships that offer comprehensive activation opportunities. Sponsors should prioritize deals that include 
              content creation rights, fan engagement opportunities, and data access.
            </p>

            <p>
              <strong>Consider team vs. series sponsorship:</strong> While series-level sponsorships offer broader reach, 
              team partnerships can provide deeper integration and more authentic storytelling opportunities, particularly 
              with the rising popularity of specific drivers and teams.
            </p>

            <p>
              <strong>Plan for multi-year commitments:</strong> The most valuable partnerships in F1 are built over time. 
              One-off sponsorships rarely achieve the ROI potential of sustained, multi-year partnerships that allow for 
              brand story development and audience relationship building.
            </p>

            <div className="bg-gray-50 p-8 rounded-lg my-12 not-prose">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Key Takeaways</h3>
              <ul className="space-y-2 text-gray-700">
                <li>• F1 sponsorship valuations continue trending upward with no plateau in sight</li>
                <li>• Digital engagement capabilities are now primary value drivers</li>
                <li>• Market expansion creates new audience segments for sponsor access</li>
                <li>• Activation potential outweighs traditional visibility metrics</li>
                <li>• Long-term partnerships yield significantly higher ROI than short-term deals</li>
              </ul>
            </div>

            <p>
              As Formula 1 continues to evolve, sponsors who understand these valuation dynamics and align their strategies 
              accordingly will be best positioned to maximize their motorsports investments. The sport's trajectory suggests 
              that 2025 will be another landmark year for partnership values and opportunities.
            </p>
          </div>

          {/* Author Bio */}
          <div className="border-t border-gray-200 pt-8 mt-12">
            <div className="flex items-start space-x-4">
              <div 
                className="w-16 h-16 bg-cover bg-center rounded-full flex-shrink-0"
                style={{
                  backgroundImage: 'url("https://suitepass.com/wp-content/uploads/2024/10/danielle-at-circuit-de-catalunya-barcelona.jpg")'
                }}
              ></div>
              <div>
                <h4 className="text-lg font-bold text-gray-900">Danielle Crespo</h4>
                <p className="text-gray-600 mb-2">Motorsports Sponsorship Consultant</p>
                <p className="text-sm text-gray-700">
                  Danielle has over a decade of experience in motorsports consulting, specializing in 
                  sponsorship strategy and executive experience design. She founded Suite Pass in 2011 
                  and has worked with events across Formula 1, IndyCar, NASCAR, and more.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

export default BlogPost;