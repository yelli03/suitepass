import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Clock, ArrowRight, TrendingUp } from 'lucide-react';

const Blog = () => {
  const featuredPost = {
    id: 'f1-sponsorship-valuations-2025',
    title: 'The Evolution of Formula 1 Sponsorship Valuations: A 2025 Market Analysis',
    excerpt: 'As Formula 1 continues its global expansion and digital transformation, sponsorship valuations have reached unprecedented levels. This comprehensive analysis examines the factors driving these valuations and what sponsors can expect in 2025.',
    date: '2025-01-15',
    readTime: '8 min read',
    image: 'https://images.pexels.com/photos/12832673/pexels-photo-12832673.jpeg',
    category: 'Market Analysis'
  };

  const recentPosts = [
    {
      id: 'executive-experience-design',
      title: 'Designing Executive Experiences That Drive Business Results',
      excerpt: 'How to create motorsports experiences that resonate with C-suite executives and deliver measurable business impact.',
      date: '2025-01-10',
      readTime: '6 min read',
      image: 'https://images.pexels.com/photos/8199562/pexels-photo-8199562.jpeg',
      category: 'Strategy'
    },
    {
      id: 'global-venue-guide',
      title: 'The Complete Guide to Premier Motorsports Venues',
      excerpt: 'Insider insights on the world\'s most prestigious racing circuits and how to maximize your presence at each location.',
      date: '2025-01-05',
      readTime: '12 min read',
      image: 'https://images.pexels.com/photos/9988739/pexels-photo-9988739.jpeg',
      category: 'Venues'
    }
  ];

  const categories = [
    { name: 'Market Analysis', count: 8, color: '#9EB9D4' },
    { name: 'Strategy', count: 12, color: '#000000' },
    { name: 'Venues', count: 6, color: '#9EB9D4' },
    { name: 'Executive Insights', count: 4, color: '#000000' }
  ];

  return (
    <main className="pt-20">
      {/* Header */}
      <div className="bg-black text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-6xl font-bold mb-6" style={{ fontFamily: '"Bodoni Poster", "Playfair Display", serif' }}>
              Insights
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              Strategic analysis, market intelligence, and expert perspectives on the evolving world of motorsports consulting.
            </p>
          </div>
        </div>
      </div>

      {/* Categories */}
      <div className="bg-gray-50 py-12 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((category, index) => (
              <button
                key={index}
                className="px-6 py-3 bg-white border border-gray-200 hover:border-gray-400 transition-colors duration-300 group"
                style={{ borderColor: category.color }}
              >
                <span className="font-medium text-black group-hover:text-gray-600 transition-colors duration-300">
                  {category.name}
                </span>
                <span className="ml-2 text-sm text-gray-500">({category.count})</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Featured Post */}
      <div className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-12">
            <div className="flex items-center mb-4">
              <TrendingUp className="h-5 w-5 mr-2" style={{ color: '#9EB9D4' }} />
              <span className="text-sm font-medium tracking-widest text-gray-500 uppercase">Featured Analysis</span>
            </div>
          </div>
          
          <article className="bg-white shadow-xl overflow-hidden border border-gray-100 lg:grid lg:grid-cols-2 lg:gap-0">
            <div 
              className="h-64 lg:h-full bg-cover bg-center"
              style={{ backgroundImage: `url(${featuredPost.image})` }}
            ></div>
            
            <div className="p-12 lg:flex lg:flex-col lg:justify-center">
              <div className="flex items-center text-sm text-gray-500 mb-4">
                <span className="px-3 py-1 bg-gray-100 text-black text-xs font-medium tracking-wide uppercase">
                  {featuredPost.category}
                </span>
                <Calendar className="h-4 w-4 ml-4 mr-2" />
                <span>{new Date(featuredPost.date).toLocaleDateString('en-US', { 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}</span>
                <Clock className="h-4 w-4 ml-4 mr-2" />
                <span>{featuredPost.readTime}</span>
              </div>
              
              <h2 className="text-4xl font-bold text-black mb-6 leading-tight" style={{ fontFamily: '"Bodoni Poster", "Playfair Display", serif' }}>
                {featuredPost.title}
              </h2>
              
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                {featuredPost.excerpt}
              </p>
              
              <Link
                to={`/insights/${featuredPost.id}`}
                className="inline-flex items-center bg-black text-white px-8 py-4 font-medium tracking-wide hover:bg-gray-800 transition-all duration-300"
              >
                READ FULL ANALYSIS
                <ArrowRight className="h-5 w-5 ml-2" />
              </Link>
            </div>
          </article>
        </div>
      </div>

      {/* Recent Posts */}
      <div className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-16">
            <h2 className="text-4xl font-bold text-black mb-6" style={{ fontFamily: '"Bodoni Poster", "Playfair Display", serif' }}>
              Recent Insights
            </h2>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12">
            {recentPosts.map((post) => (
              <article
                key={post.id}
                className="bg-white shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 border border-gray-100"
              >
                <div 
                  className="h-48 bg-cover bg-center"
                  style={{ backgroundImage: `url(${post.image})` }}
                ></div>
                
                <div className="p-8">
                  <div className="flex items-center text-sm text-gray-500 mb-4">
                    <span className="px-3 py-1 bg-gray-100 text-black text-xs font-medium tracking-wide uppercase">
                      {post.category}
                    </span>
                    <Calendar className="h-4 w-4 ml-4 mr-2" />
                    <span>{new Date(post.date).toLocaleDateString('en-US', { 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}</span>
                    <Clock className="h-4 w-4 ml-4 mr-2" />
                    <span>{post.readTime}</span>
                  </div>
                  
                  <h3 className="text-2xl font-bold text-black mb-4 leading-tight">
                    {post.title}
                  </h3>
                  
                  <p className="text-gray-600 mb-6 leading-relaxed">
                    {post.excerpt}
                  </p>
                  
                  <Link
                    to={`/insights/${post.id}`}
                    className="inline-flex items-center text-black hover:text-gray-600 font-medium transition-colors duration-300"
                  >
                    <span className="tracking-wide">READ MORE</span>
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>

      {/* Newsletter CTA */}
      <div className="py-20 bg-black text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6" style={{ fontFamily: '"Bodoni Poster", "Playfair Display", serif' }}>
            Stay Informed
          </h2>
          <p className="text-xl text-gray-300 mb-8 leading-relaxed">
            Receive exclusive insights and market intelligence directly from our consulting team.
          </p>
          
          <form className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
            <input
              type="email"
              placeholder="Enter your email address"
              className="flex-1 px-6 py-4 text-black focus:ring-2 focus:ring-blue-300 focus:outline-none"
            />
            <button
              type="submit"
              className="bg-white text-black px-8 py-4 font-medium tracking-wide hover:bg-gray-100 transition-colors duration-300"
            >
              SUBSCRIBE
            </button>
          </form>
        </div>
      </div>
    </main>
  );
};

export default Blog;