import React from 'react';
import { ArrowRight, CheckCircle, Users, Target, TrendingUp, Award, Globe, Zap } from 'lucide-react';

const Home = () => {
  const partners = [
    { name: 'Formula 1', logo: 'F1' },
    { name: 'IndyCar', logo: 'INDYCAR' },
    { name: 'IMSA', logo: 'IMSA' },
    { name: 'NASCAR', logo: 'NASCAR' },
    { name: 'MotoGP', logo: 'MotoGP' },
    { name: 'Formula E', logo: 'FE' }
  ];

  const services = [
    {
      icon: Target,
      title: 'Sponsorship Strategy',
      description: 'Maximize ROI through strategic partnership development and activation planning.',
      link: '/services#sponsorship'
    },
    {
      icon: Users,
      title: 'Executive Experiences',
      description: 'Curated high-impact experiences designed for C-suite executives and key stakeholders.',
      link: '/services#executive'
    },
    {
      icon: Globe,
      title: 'Global Event Management',
      description: 'End-to-end event coordination across premier motorsports venues worldwide.',
      link: '/services#events'
    },
    {
      icon: TrendingUp,
      title: 'Market Intelligence',
      description: 'Data-driven insights and competitive analysis for informed decision making.',
      link: '/services#intelligence'
    }
  ];

  const achievements = [
    { number: '13+', label: 'Years Experience' },
    { number: '50+', label: 'Events Managed' },
    { number: '25+', label: 'Global Venues' },
    { number: '100+', label: 'Executive Experiences' }
  ];

  const testimonials = [
    {
      quote: "Suite Pass delivered exceptional value in navigating our F1 partnership. Their insider knowledge and strategic approach maximized our investment.",
      author: "Chief Marketing Officer",
      company: "Fortune 500 Technology Company"
    },
    {
      quote: "The executive experience they created for our leadership team at Monaco was flawless. Every detail was perfectly orchestrated.",
      author: "VP of Corporate Development",
      company: "Global Financial Services"
    }
  ];

  return (
    <main className="pt-20">
      {/* Video Hero Section */}
      <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Video Background */}
        <div className="absolute inset-0 w-full h-full">
          <video
            autoPlay
            muted
            loop
            playsInline
            className="w-full h-full object-cover"
            poster="https://images.pexels.com/photos/12832673/pexels-photo-12832673.jpeg"
          >
            <source src="https://player.vimeo.com/external/434045526.sd.mp4?s=c27eecc69a27dbc4ff2b87d38afc35f1c9a1a8f4&profile_id=139&oauth2_token_id=57447761" type="video/mp4" />
          </video>
        </div>
        
        {/* Video Overlay */}
        <div className="video-overlay-div absolute inset-0 bg-black/40"></div>
        
        {/* Hero Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
          <h1 className="text-6xl md:text-8xl font-bold mb-6 tracking-tight leading-none" style={{ fontFamily: '"Bodoni Poster", "Playfair Display", serif' }}>
            SUITE PASS
          </h1>
          <p className="text-2xl md:text-3xl font-light mb-8 max-w-4xl mx-auto leading-relaxed">
            Elevated Motorsport Sponsorship Consulting for Global Enterprises
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <a
              href="#contact"
              className="bg-white text-black px-8 py-4 text-lg font-medium tracking-wide hover:bg-gray-100 transition-all duration-300 border border-white hover:shadow-2xl"
            >
              REQUEST CONSULTATION
            </a>
            <a
              href="#services"
              className="border-2 border-white text-white px-8 py-4 text-lg font-medium tracking-wide hover:bg-white hover:text-black transition-all duration-300"
            >
              VIEW SERVICES
            </a>
          </div>
        </div>
      </div>

      {/* Partners Section */}
      <div className="bg-white py-16 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-sm font-medium tracking-widest text-gray-500 uppercase mb-4">Trusted by Leading Organizations</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 items-center">
            {partners.map((partner, index) => (
              <div key={index} className="flex justify-center">
                <div className="text-2xl font-bold text-gray-400 hover:text-black transition-colors duration-300 cursor-pointer">
                  {partner.logo}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Services Section */}
      <div id="services" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold text-black mb-6" style={{ fontFamily: '"Bodoni Poster", "Playfair Display", serif' }}>
              Our Expertise
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Comprehensive motorsports consulting services designed to maximize your investment and create lasting impact.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-white p-8 hover:shadow-xl transition-all duration-300 group cursor-pointer border border-gray-100">
                <div className="mb-6">
                  <service.icon className="h-12 w-12 text-black group-hover:text-blue-300 transition-colors duration-300" style={{ color: '#9EB9D4' }} />
                </div>
                <h3 className="text-xl font-bold text-black mb-4">{service.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>
                <div className="flex items-center text-black group-hover:text-blue-300 transition-colors duration-300" style={{ color: '#9EB9D4' }}>
                  <span className="text-sm font-medium tracking-wide">LEARN MORE</span>
                  <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform duration-300" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Achievements Section */}
      <div className="py-20 bg-black text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            {achievements.map((achievement, index) => (
              <div key={index} className="group">
                <div className="text-5xl font-bold mb-2 group-hover:text-blue-300 transition-colors duration-300" style={{ color: '#9EB9D4' }}>
                  {achievement.number}
                </div>
                <div className="text-lg font-medium tracking-wide text-gray-300">
                  {achievement.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* About Section */}
      <div className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-5xl font-bold text-black mb-8 leading-tight" style={{ fontFamily: '"Bodoni Poster", "Playfair Display", serif' }}>
                Expertise Born from Passion
              </h2>
              <div className="space-y-6 text-lg text-gray-600 leading-relaxed">
                <p>
                  Since 2011, Suite Pass has been at the forefront of motorsports consulting, beginning with the inaugural 
                  United States Grand Prix in Austin, Texas. Our journey started with curiosity and has evolved into a 
                  sophisticated consultancy serving Fortune 500 companies and global enterprises.
                </p>
                <p>
                  We specialize in transforming complex motorsports partnerships into strategic business advantages, 
                  creating experiences that resonate from the C-suite to the grandstands.
                </p>
              </div>
              
              <div className="mt-8 space-y-4">
                {[
                  'Deep industry relationships across all major series',
                  'Proven track record with Fortune 500 companies',
                  'Global venue expertise spanning 25+ locations',
                  'Data-driven approach to partnership optimization'
                ].map((item, index) => (
                  <div key={index} className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">{item}</span>
                  </div>
                ))}
              </div>

              <div className="mt-10">
                <a
                  href="#contact"
                  className="bg-black text-white px-8 py-4 text-lg font-medium tracking-wide hover:bg-gray-800 transition-all duration-300 inline-flex items-center"
                >
                  START YOUR PROJECT
                  <ArrowRight className="h-5 w-5 ml-2" />
                </a>
              </div>
            </div>
            
            <div className="relative">
              <div 
                className="aspect-square bg-cover bg-center shadow-2xl"
                style={{
                  backgroundImage: 'url("https://suitepass.com/wp-content/uploads/2024/10/danielle-at-circuit-de-catalunya-barcelona.jpg")'
                }}
              ></div>
              <div className="absolute -bottom-6 -right-6 bg-white p-6 shadow-xl border border-gray-100">
                <div className="text-center">
                  <div className="text-2xl font-bold text-black">Danielle Crespo</div>
                  <div className="text-sm text-gray-600 mt-1">Founder & Principal Consultant</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Testimonials Section */}
      <div className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold text-black mb-6" style={{ fontFamily: '"Bodoni Poster", "Playfair Display", serif' }}>
              Client Success
            </h2>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white p-8 shadow-lg border border-gray-100">
                <div className="mb-6">
                  <div className="text-4xl text-blue-300 mb-4" style={{ color: '#9EB9D4' }}>"</div>
                  <p className="text-lg text-gray-700 leading-relaxed italic">
                    {testimonial.quote}
                  </p>
                </div>
                <div className="border-t border-gray-100 pt-6">
                  <div className="font-bold text-black">{testimonial.author}</div>
                  <div className="text-sm text-gray-600">{testimonial.company}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Contact Section */}
      <div id="contact" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16">
            <div>
              <h2 className="text-5xl font-bold text-black mb-8 leading-tight" style={{ fontFamily: '"Bodoni Poster", "Playfair Display", serif' }}>
                Ready to Elevate Your Motorsports Strategy?
              </h2>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Let's discuss how Suite Pass can transform your motorsports partnerships into strategic business advantages.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mr-4">
                    <Zap className="h-6 w-6 text-black" />
                  </div>
                  <div>
                    <div className="font-bold text-black">Strategic Consultation</div>
                    <div className="text-gray-600">Comprehensive partnership analysis and optimization</div>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mr-4">
                    <Award className="h-6 w-6 text-black" />
                  </div>
                  <div>
                    <div className="font-bold text-black">Executive Experiences</div>
                    <div className="text-gray-600">Curated events for leadership teams and key stakeholders</div>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mr-4">
                    <Globe className="h-6 w-6 text-black" />
                  </div>
                  <div>
                    <div className="font-bold text-black">Global Reach</div>
                    <div className="text-gray-600">Expertise across premier venues worldwide</div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 p-8 border border-gray-100">
              <form className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="firstName" className="block text-sm font-medium text-black mb-2 tracking-wide">
                      FIRST NAME *
                    </label>
                    <input
                      type="text"
                      id="firstName"
                      required
                      className="w-full px-4 py-3 border border-gray-300 focus:ring-2 focus:ring-blue-300 focus:border-blue-300 transition-colors"
                      style={{ focusRingColor: '#9EB9D4' }}
                    />
                  </div>
                  <div>
                    <label htmlFor="lastName" className="block text-sm font-medium text-black mb-2 tracking-wide">
                      LAST NAME *
                    </label>
                    <input
                      type="text"
                      id="lastName"
                      required
                      className="w-full px-4 py-3 border border-gray-300 focus:ring-2 focus:ring-blue-300 focus:border-blue-300 transition-colors"
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-black mb-2 tracking-wide">
                    EMAIL ADDRESS *
                  </label>
                  <input
                    type="email"
                    id="email"
                    required
                    className="w-full px-4 py-3 border border-gray-300 focus:ring-2 focus:ring-blue-300 focus:border-blue-300 transition-colors"
                  />
                </div>
                
                <div>
                  <label htmlFor="company" className="block text-sm font-medium text-black mb-2 tracking-wide">
                    COMPANY
                  </label>
                  <input
                    type="text"
                    id="company"
                    className="w-full px-4 py-3 border border-gray-300 focus:ring-2 focus:ring-blue-300 focus:border-blue-300 transition-colors"
                  />
                </div>
                
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-black mb-2 tracking-wide">
                    PROJECT DETAILS
                  </label>
                  <textarea
                    id="message"
                    rows={4}
                    className="w-full px-4 py-3 border border-gray-300 focus:ring-2 focus:ring-blue-300 focus:border-blue-300 transition-colors"
                    placeholder="Tell us about your motorsports objectives and how we can help..."
                  ></textarea>
                </div>
                
                <button
                  type="submit"
                  className="w-full bg-black text-white px-6 py-4 text-lg font-medium tracking-wide hover:bg-gray-800 transition-all duration-300"
                >
                  SEND MESSAGE
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

export default Home;